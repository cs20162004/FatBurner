package com.example.fatburner;

class Constants {
    static final int LOCATION_SERVICE_ID = 175;
    static final String ACTION_START_LOCATION_SERVICE = "startlocationservice";
    static final String ACTION_STOP_LOCATION_SERVICE = "stoplocationservice";
}
